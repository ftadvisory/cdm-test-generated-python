'''rosetta runtime package'''
# PEP 396 module version attribute in PEP 440 version format
from .version import __version__

# EOF
