from enum import Enum

all = ['ArithmeticOperationEnum']
  
class ArithmeticOperationEnum(Enum):
  """
  An arithmetic operator that can be passed to a function
  """
  ADD = "Add"
  """
  Addition
  """
  DIVIDE = "Divide"
  """
  Division
  """
  MAX = "Max"
  """
  Max of 2 values
  """
  MIN = "Min"
  """
  Min of 2 values
  """
  MULTIPLY = "Multiply"
  """
  Multiplication
  """
  SUBTRACT = "Subtract"
  """
  Subtraction
  """
