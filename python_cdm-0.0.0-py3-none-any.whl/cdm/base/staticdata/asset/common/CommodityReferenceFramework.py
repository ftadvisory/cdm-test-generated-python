# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import *

__all__ = ['CommodityReferenceFramework']


class CommodityReferenceFramework(BaseDataClass):
  """
  Specifies the type of commodity.
  """
  capacityUnit: Optional[CapacityUnitEnum] = Field(None, description="Provides an enumerated value for a capacity unit, generally used in the context of defining quantities for commodities.")
  """
  Provides an enumerated value for a capacity unit, generally used in the context of defining quantities for commodities.
  """
  commodityClassification: List[AttributeWithMeta[Taxonomy] | Taxonomy] = Field([], description="Identifies a commodity using one or several identification systems (ex.: EMIR Refit Table 4 of the Annex to the Comission Implementing Regulation C(2022) 3588, ISDA 2005 Commodity Definitions SubAnnex A, etc.) with any number of hierarchical layers.")
  """
  Identifies a commodity using one or several identification systems (ex.: EMIR Refit Table 4 of the Annex to the Comission Implementing Regulation C(2022) 3588, ISDA 2005 Commodity Definitions SubAnnex A, etc.) with any number of hierarchical layers.
  """
  commodityName: str = Field(..., description="Identifies the commodity more specifically. Where possible, this should follow the naming convention used in the 2005 ISDA Commodity Definitions SubAnnex A, including the subCommodity and additional qualifiers, but should be limited to 256 characters or less.")
  """
  Identifies the commodity more specifically. Where possible, this should follow the naming convention used in the 2005 ISDA Commodity Definitions SubAnnex A, including the subCommodity and additional qualifiers, but should be limited to 256 characters or less.
  """
  currency: AttributeWithMeta[str] | str = Field(..., description="Defines the currency in which the commodity is priced.")
  """
  Defines the currency in which the commodity is priced.
  """
  weatherUnit: Optional[WeatherUnitEnum] = Field(None, description="Provides an enumerated values for a weather unit, generally used in the context of defining quantities for commodities.")
  """
  Provides an enumerated values for a weather unit, generally used in the context of defining quantities for commodities.
  """
  
  @rosetta_condition
  def condition_0_CommodityReferenceFrameworkChoice(self):
    """
    Requires that either the capacity unit or weather unit is populated.
    """
    return self.check_one_of_constraint('capacityUnit', 'weatherUnit', necessity=False)
  
  @rosetta_condition
  def condition_1_OrdinalExists(self):
    """
    Requires that, if multiple classification elements are present, they contain an  ordinal so that they can be sorted.
    """
    def _then_fn0():
      return ((_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "commodityClassification"), "value"), "classification"), "ordinal")) is not None)
    
    def _else_fn0():
      return True
    
    return if_cond_fn(all_elements(len(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "commodityClassification"), "value"), "classification")), ">", 1), _then_fn0, _else_fn0)
  
  @rosetta_condition
  def condition_2_DifferentOrdinals(self):
    """
    Prevents several identical ordinals from being specified in the same commodity classification, since classification values for each classification layer are mutually exclusive (i.e.: only a value can exist for each layer).
    """
    def _then_fn0():
      return DifferentOrdinalsCondition()
    
    def _else_fn0():
      return True
    
    return if_cond_fn(((_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(_resolve_rosetta_attr(self, "commodityClassification"), "value"), "classification"), "ordinal")) is not None), _then_fn0, _else_fn0)

from cdm.base.math.CapacityUnitEnum import CapacityUnitEnum
from cdm.base.staticdata.asset.common.Taxonomy import Taxonomy
from cdm.base.math.WeatherUnitEnum import WeatherUnitEnum
from cdm.base.staticdata.asset.common.functions.DifferentOrdinalsCondition import DifferentOrdinalsCondition

CommodityReferenceFramework.update_forward_refs()
