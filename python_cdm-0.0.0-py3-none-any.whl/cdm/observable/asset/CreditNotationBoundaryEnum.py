from enum import Enum

all = ['CreditNotationBoundaryEnum']
  
class CreditNotationBoundaryEnum(Enum):
  """
  Identifies an agency rating as a simple scale boundary of minimum or maximum.
  """
  MAXIMUM = "Maximum"
  """
  Denotes a maxiumum boundary
  """
  MINIMUM = "Minimum"
  """
  Denotes a minumum boundary
  """
