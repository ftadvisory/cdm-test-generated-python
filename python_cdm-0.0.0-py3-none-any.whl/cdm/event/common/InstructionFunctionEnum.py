from enum import Enum

all = ['InstructionFunctionEnum']
  
class InstructionFunctionEnum(Enum):
  """
  The enumeration values indicating the BusinessEvent function associated input instructions.
  """
  COMPRESSION = "Compression"
  CONTRACT_FORMATION = "ContractFormation"
  EXECUTION = "Execution"
  QUANTITY_CHANGE = "QuantityChange"
  RENEGOTIATION = "Renegotiation"
