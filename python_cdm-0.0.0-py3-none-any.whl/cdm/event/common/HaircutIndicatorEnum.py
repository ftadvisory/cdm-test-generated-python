from enum import Enum

all = ['HaircutIndicatorEnum']
  
class HaircutIndicatorEnum(Enum):
  """
  Represents the enumeration indicators to specify if an asset or group of assets valuation is based on any valuation treatment haircut.
  """
  POST_HAIRCUT = "PostHaircut"
  """
  Indicates Post haircut value
  """
  PRE_HAIRCUT = "PreHaircut"
  """
  Indicates Pre haircut value
  """
