from enum import Enum

all = ['ValuationSourceEnum']
  
class ValuationSourceEnum(Enum):
  """
  Source for the valuation of the transaction by the valuation party.
  """
  CENTRAL_COUNTERPARTY = "CENTRAL_COUNTERPARTY"
  """
  Central Counterparty's Valuation
  """
