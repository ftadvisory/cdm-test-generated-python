from enum import Enum

all = ['RegIMRoleEnum']
  
class RegIMRoleEnum(Enum):
  """
  Represents the enumeration values to specify the role of the party in relation to a regulatory initial margin call.
  """
  PLEDGOR = "Pledgor"
  """
  Indicates 'Pledgor' party of initial margin call.
  """
  SECURED = "Secured"
  """
  Indicates 'Secured' party of initial margin call.
  """
