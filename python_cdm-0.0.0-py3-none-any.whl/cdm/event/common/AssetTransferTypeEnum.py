from enum import Enum

all = ['AssetTransferTypeEnum']
  
class AssetTransferTypeEnum(Enum):
  """
  The qualification of the type of asset transfer.
  """
  FREE_OF_PAYMENT = "FreeOfPayment"
  """
  The transfer of assets takes place without a corresponding exchange of payment.
  """
