from enum import Enum

all = ['ContractualDefinitionsEnum']
  
class ContractualDefinitionsEnum(Enum):
  """
  The enumerated values to specify a set of standard contract definitions relevant to the transaction.
  """
  ISDA1991 = "ISDA1991"
  """
  ISDA 1991 Interest Rate Definitions
  """
  ISDA_1993_COMMODITY = "ISDA1993Commodity"
  """
  ISDA 1993 Commodity Derivatives Definitions
  """
  ISDA_1996_EQUITY = "ISDA1996Equity"
  """
  ISDA 1996 Equity Derivatives Definitions
  """
  ISDA_1997_BULLION = "ISDA1997Bullion"
  """
  ISDA 1997 Bullion Definitions
  """
  ISDA_1997_GOVERNMENT_BOND = "ISDA1997GovernmentBond"
  """
  ISDA 1997 Government Bond Option Definitions
  """
  ISDA1998FX = "ISDA1998FX"
  """
  ISDA 1998 FX and Currency Option Definitions
  """
  ISDA_1999_CREDIT = "ISDA1999Credit"
  """
  ISDA 1999 Credit Derivatives Definitions
  """
  ISDA2000 = "ISDA2000"
  """
  ISDA 2000 Definitions
  """
  ISDA_2002_EQUITY = "ISDA2002Equity"
  """
  ISDA 2002 Equity Derivatives Definitions
  """
  ISDA_2003_CREDIT = "ISDA2003Credit"
  """
  ISDA 2003 Credit Derivatives Definitions
  """
  ISDA_2004_NOVATION = "ISDA2004Novation"
  """
  ISDA 2004 Novation Definitions
  """
  ISDA_2005_COMMODITY = "ISDA2005Commodity"
  """
  ISDA 2005 Commodity Derivatives Definitions
  """
  ISDA2006 = "ISDA2006"
  """
  ISDA 2006 Interest Rate Definitions
  """
  ISDA_2006_INFLATION = "ISDA2006Inflation"
  """
  ISDA 2006 Inflation Derivatives Definitions
  """
  ISDA_2008_INFLATION = "ISDA2008Inflation"
  """
  ISDA 2008 Inflation Derivatives Definitions
  """
  ISDA_2011_EQUITY = "ISDA2011Equity"
  """
  ISDA 2011 Equity Derivatives Definitions
  """
  ISDA_2014_CREDIT = "ISDA2014Credit"
  """
  ISDA 2014 Credit Derivatives Definitions
  """
  ISDA2021 = "ISDA2021"
  """
  ISDA 2021 Interest Rate Derivatives Definitions
  """
