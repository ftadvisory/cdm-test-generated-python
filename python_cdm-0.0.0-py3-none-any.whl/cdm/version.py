version = (0,0,0,0)
version_str = '0.0.0-0'
__version__ = '0,0,0'
__build_time__ = '2023-10-16T09:58:36.661772'