from enum import Enum

all = ['RoundingModeEnum']
  
class RoundingModeEnum(Enum):
  DOWN = "DOWN"
  UP = "UP"
