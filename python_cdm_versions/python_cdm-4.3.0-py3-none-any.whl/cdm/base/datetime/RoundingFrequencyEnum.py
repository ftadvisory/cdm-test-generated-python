from enum import Enum

all = ['RoundingFrequencyEnum']
  
class RoundingFrequencyEnum(Enum):
  """
  How often is rounding performed
  """
  DAILY = "DAILY"
  """
  Rounding is done on each day
  """
  PERIOD_END = "PERIOD_END"
  """
  Rounding is done only at the end of the period
  """
