from enum import Enum

all = ['WarehouseIdentityEnum']
  
class WarehouseIdentityEnum(Enum):
  DTCC_TIW_GOLD = "DTCC_TIW_Gold"
  """
  The DTCC Trade Information Warehouse Gold service
  """
