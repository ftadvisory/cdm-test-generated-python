from enum import Enum

all = ['CompareOp']
  
class CompareOp(Enum):
  EQUALS = "Equals"
  GREATER_THAN = "GreaterThan"
  GREATER_THAN_OR_EQUALS = "GreaterThanOrEquals"
  LESS_THAN = "LessThan"
  LESS_THAN_OR_EQUALS = "LessThanOrEquals"
