from enum import Enum

all = ['PriceTimingEnum']
  
class PriceTimingEnum(Enum):
  CLOSING_PRICE = "ClosingPrice"
  """
  The last price anyone paid for a share of a product during the business hours of the exchange where the product is traded on a business day.
  """
  OPENING_PRICE = "OpeningPrice"
  """
  The first price anyone paid for a share of a product during the business hours of the exchange where the product is traded on a business day.
  """
