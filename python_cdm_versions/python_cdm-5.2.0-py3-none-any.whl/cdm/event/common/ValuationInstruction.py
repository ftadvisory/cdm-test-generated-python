# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import *

__all__ = ['ValuationInstruction']


class ValuationInstruction(BaseDataClass):
  """
  Specifies inputs needed to process a valuation.
  """
  valuation: List[Valuation] = Field([], description="Contains all information related to a valuation.")
  """
  Contains all information related to a valuation.
  """
  @rosetta_condition
  def cardinality_valuation(self):
    return check_cardinality(self.valuation, 1, None)
  
  replace: bool = Field(..., description="Specifies whether the previous valuation tracks in the valuation history are removed (True) or kept (False).")
  """
  Specifies whether the previous valuation tracks in the valuation history are removed (True) or kept (False).
  """

from cdm.event.common.Valuation import Valuation

ValuationInstruction.update_forward_refs()
