# pylint: disable=line-too-long, invalid-name, missing-function-docstring, missing-module-docstring, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import, wildcard-import, wrong-import-order, missing-class-docstring
from __future__ import annotations
from typing import List, Optional
from datetime import date
from datetime import time
from datetime import datetime
from decimal import Decimal
from pydantic import Field
from rosetta.runtime.utils import *

__all__ = ['CounterpartyPositionBusinessEvent']


class CounterpartyPositionBusinessEvent(BaseDataClass):
  """
  A business event represents a life cycle event of a position. The combination of the state changes results in a qualifiable life cycle event.
  """
  intent: PositionEventIntentEnum = Field(..., description="The intent attribute is meant to be specified when the event qualification cannot be programmatically inferred from the event features. As a result it is only associated with those primitives that can give way to such ambiguity, the quantityChange being one of those.")
  """
  The intent attribute is meant to be specified when the event qualification cannot be programmatically inferred from the event features. As a result it is only associated with those primitives that can give way to such ambiguity, the quantityChange being one of those.
  """
  corporateActionIntent: Optional[CorporateActionTypeEnum] = Field(None, description="The intent of a corporate action on the position.")
  """
  The intent of a corporate action on the position.
  """
  eventDate: Optional[date] = Field(None, description="Specifies the date on which the event is taking place. This date is equal to the trade date in the case of a simple execution. However it can be different from the trade date, for example in the case of a partial termination.")
  """
  Specifies the date on which the event is taking place. This date is equal to the trade date in the case of a simple execution.  However it can be different from the trade date, for example in the case of a partial termination.
  """
  effectiveDate: Optional[date] = Field(None, description="The date on which the event contractually takes effect, when different from the event date.")
  """
  The date on which the event contractually takes effect, when different from the event date.
  """
  packageInformation: Optional[IdentifiedList] = Field(None, description="Specifies the package information in case the business event represents several trades executed as a package (hence this attribute is optional). The package information is only instantiated once at the business event level to preserve referential integrity, whereas individual trades make reference to it to identify that they are part of a package.")
  """
  Specifies the package information in case the business event represents several trades executed as a package (hence this attribute is optional). The package information is only instantiated once at the business event level to preserve referential integrity, whereas individual trades make reference to it to identify that they are part of a package.
  """
  after: List[CounterpartyPositionState] = Field([], description="Specifies the after position state(s) created.")
  """
  Specifies the after position state(s) created.
  """

from cdm.event.common.PositionEventIntentEnum import PositionEventIntentEnum
from cdm.event.common.CorporateActionTypeEnum import CorporateActionTypeEnum
from cdm.base.staticdata.identifier.IdentifiedList import IdentifiedList
from cdm.event.common.CounterpartyPositionState import CounterpartyPositionState

CounterpartyPositionBusinessEvent.update_forward_refs()
