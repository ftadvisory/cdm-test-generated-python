from enum import Enum

all = ['WorkflowStatusEnum']
  
class WorkflowStatusEnum(Enum):
  ACCEPTED = "Accepted"
  AFFIRMED = "Affirmed"
  ALLEGED = "Alleged"
  AMENDED = "Amended"
  CANCELLED = "Cancelled"
  CERTAIN = "Certain"
  CLEARED = "Cleared"
  CONFIRMED = "Confirmed"
  PENDING = "Pending"
  REJECTED = "Rejected"
  SUBMITTED = "Submitted"
  TERMINATED = "Terminated"
  UNCERTAIN = "Uncertain"
  UNCONFIRMED = "Unconfirmed"
