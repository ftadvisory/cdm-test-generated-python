from enum import Enum

all = ['MoneyMarketTypeEnum']
  
class MoneyMarketTypeEnum(Enum):
  CERTIFICATE_OF_DEPOSIT = "CertificateOfDeposit"
  COMMERCIAL_PAPER = "CommercialPaper"
