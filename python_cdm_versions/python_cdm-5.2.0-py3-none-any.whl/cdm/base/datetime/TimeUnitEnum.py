from enum import Enum

all = ['TimeUnitEnum']
  
class TimeUnitEnum(Enum):
  """
  The enumeration values to qualify the allowed units of time.
  """
  DAY = "Day"
  """
  Day
  """
  HOUR = "Hour"
  """
  Hour
  """
  MINUTE = "Minute"
  """
  Minute
  """
  MONTH = "Month"
  """
  Month
  """
  SECOND = "Second"
  """
  Second
  """
  WEEK = "Week"
  """
  Week
  """
  YEAR = "Year"
  """
  Year
  """
