version = (5,2,0,0)
version_str = '5.2.0-0'
__version__ = '5,2,0'
__build_time__ = '2023-12-01T19:05:07.183711'